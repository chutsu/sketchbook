# Take-Home Coding Challenge: Trajectory Retiming

Thank you for taking the time to complete this challenge. Please read the instructions carefully before you begin.

---

## Scenario

A construction robot performs surface treatment (e.g., concrete removal, coating application) on building elements. Its joint-space trajectory has been optimized for minimal total execution time — but the resulting Cartesian end-effector speed exceeds the tool's maximum allowable velocity.

Your task is to **retime** the trajectory: stretch it in time so that all constraints are respected, while keeping the path geometry exactly as-is and minimizing the added time penalty.

---

## Your Task

Implement the `retime_trajectory()` function in `trajectory_retiming/retimer.py`.

The function signature and docstring are already in place. The implementation body is left for you to fill in.

**Requirements — the retimed trajectory must:**

- Keep Cartesian end-effector speed ≤ `limits.max_cartesian_speed`
- Keep joint velocities ≤ `limits.max_joint_velocities` for every joint
- Keep joint accelerations ≤ `limits.max_joint_accelerations` for every joint
- Preserve all original waypoint positions (path geometry must not change)
- Produce monotonically increasing timestamps
- Minimize the total trajectory duration while satisfying all of the above

---

## What's Provided

```
trajectory_retiming/
├── retimer.py          # Your implementation goes here
├── data_types.py       # JointState, JointTrajectory, CartesianPose
├── kinematics.py       # Forward kinematics and Jacobian for the UR30
├── limits.py           # RobotLimits dataclass
└── __init__.py

examples/
└── p2p_trajectory.json # Example point-to-point trajectory you can use for development
```

The robot is a **UR30** (Universal Robots, 6-DOF). Its kinematics are implemented for you — you do not need to derive or verify them.

---

## Evaluation Criteria

We will evaluate your submission on:

1. **Correctness** — Does your implementation satisfy all constraints?
2. **Testing** — Do you write tests that validate your implementation? What edge cases do you consider?
3. **Code quality** — Is the code readable, well-structured, and maintainable?
4. **Reasoning** — Does your approach make sense? Explain your algorithm and any trade-offs in comments or a brief write-up.

---

## What to Submit

Send back the entire repository. At a minimum we will look at:

- `trajectory_retiming/retimer.py` — your implementation
- Any test files you create
- Any notes or comments explaining your approach (inline or in a separate file)

---

## Time Guidance

We expect this challenge to take **2–4 hours**. You do not need to over-engineer it — a clean, well-reasoned solution is more valuable than an exhaustive one.

If you run out of time or make a deliberate trade-off, note it in your submission.

---

## Setup

**Prerequisites:** Python 3.8 or higher, pip

```bash
# Create and activate a virtual environment
python3 -m venv venv
source venv/bin/activate

# Install dependencies
pip install -r requirements.txt
```

```bash
# Deactivate when done
deactivate
```

---

## Visualization

Use the built-in visualizer to inspect trajectories during development:

```bash
# Plot the example trajectory
python3 -m trajectory_retiming.retimer

# Plot a custom trajectory file
python3 -m trajectory_retiming.retimer --trajectory path/to/your_trajectory.json
```

This shows joint positions over time, joint velocities, Cartesian end-effector speed, and the 3D path.

**Note:** Run from the project root using `python3 -m trajectory_retiming.retimer` (not `python3 retimer.py`) so that package imports resolve correctly.
