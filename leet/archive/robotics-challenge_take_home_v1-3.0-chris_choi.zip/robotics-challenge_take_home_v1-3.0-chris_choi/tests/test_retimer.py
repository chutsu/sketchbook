from collections import defaultdict

import numpy as np
import matplotlib.pylab as plt

from trajectory_retiming.limits import RobotLimits
from trajectory_retiming.kinematics import UR30_DH_PARAMS
from trajectory_retiming.retimer import build_splines
from trajectory_retiming.retimer import is_feasible
from trajectory_retiming.retimer import optimize_nlls
from trajectory_retiming.retimer import optimize_line_search
from trajectory_retiming.retimer import plot_trajectory


def test_build_splines(test_traj):
  """ Test build splines """
  # Exact times and waypoints per joint
  num_joints = len(UR30_DH_PARAMS)
  times = test_traj.time_from_start
  waypoints = defaultdict(list)
  for joint_state in test_traj.waypoints:
    for i in range(num_joints):
      waypoints[i].append(joint_state.positions[i])

  # Build cubic splines per joint
  splines = build_splines(waypoints, times)

  # Visualize
  debug = False
  if debug:
    colors = ['#e63946', '#f4a261', '#2a9d8f', '#264653', '#9b5de5', '#00bbf9']
    _, ax = plt.subplots(figsize=(6.5, 4))
    for i in range(num_joints):
      ax.plot(times,
              waypoints[i],
              'x',
              color=colors[i],
              label=f"joint{i} - data",
              alpha=0.2)
      ax.plot(times,
              splines[i](times),
              '-',
              color=colors[i],
              label=f"joint{i} - spline")
    plt.legend(loc=0)
    plt.show()


def test_pass_feasibility(test_traj):
  """ Test pass feasibility """
  num_joints = len(UR30_DH_PARAMS)

  s = 10.0
  times = s * np.array(test_traj.time_from_start)
  waypoints = [[] for _ in range(num_joints)]
  for joint_state in test_traj.waypoints:
    for i in range(num_joints):
      waypoints[i].append(joint_state.positions[i])
  splines = build_splines(waypoints, times)

  # Visualize
  debug = False
  if debug:
    colors = [
      '#e63946',
      '#f4a261',
      '#2a9d8f',
      '#264653',
      '#9b5de5',
      '#00bbf9',
    ]
    _, ax = plt.subplots(figsize=(6.5, 4))
    for i in range(num_joints):
      label = f"joint{i} - spline"
      xs = times
      ys = splines[i](times)
      ax.plot(xs, ys, '-', color=colors[i], label=label)
    plt.legend(loc=0)
    plt.show()

  # Assert
  assert is_feasible(splines, times) is True


def test_fail_feasibility(test_traj):
  """ Test fail feasibility """
  num_joints = len(UR30_DH_PARAMS)

  s = 0.01
  times = s * np.array(test_traj.time_from_start)
  waypoints = [[] for _ in range(num_joints)]
  for joint_state in test_traj.waypoints:
    for i in range(num_joints):
      waypoints[i].append(joint_state.positions[i])
  splines = build_splines(waypoints, times)

  # Visualize
  debug = False
  if debug:
    colors = [
      '#e63946',
      '#f4a261',
      '#2a9d8f',
      '#264653',
      '#9b5de5',
      '#00bbf9',
    ]
    _, ax = plt.subplots(figsize=(6.5, 4))
    for i in range(num_joints):
      label = f"joint{i} - spline"
      xs = times
      ys = splines[i](times)
      ax.plot(xs, ys, '-', color=colors[i], label=label)
    plt.legend(loc=0)
    plt.show()

  # Assert
  assert is_feasible(splines, times) is False


def test_optimize_line_search(test_traj):
  """ Test line search """
  # Optimize
  limits = RobotLimits()
  traj_opt = optimize_line_search(test_traj)

  # Assert correctness
  num_joints = 6
  times = np.array(traj_opt.time_from_start)
  waypoints = [[] for _ in range(num_joints)]
  for joint_state in traj_opt.waypoints:
    for i in range(num_joints):
      waypoints[i].append(joint_state.positions[i])
  splines = build_splines(waypoints, times)
  assert is_feasible(splines, times, limits)

  # Visualize
  debug = True
  if debug:
    plot_trajectory(traj_opt)


# def test_optimize_nlls(test_traj):
#   """ Test Non-linear least squares """
#   # Optimize
#   limits = RobotLimits()
#   traj_opt = optimize_nlls(test_traj, limits)
#
#   # Assert correctness
#   num_joints = 6
#   times = np.array(traj_opt.time_from_start)
#   waypoints = [[] for _ in range(num_joints)]
#   for joint_state in traj_opt.waypoints:
#     for i in range(num_joints):
#       waypoints[i].append(joint_state.positions[i])
#   splines = build_splines(waypoints, times)
#   assert is_feasible(splines, times, limits)
#
#   # Visualize
#   debug = False
#   if debug:
#     plot_trajectory(traj_opt)
