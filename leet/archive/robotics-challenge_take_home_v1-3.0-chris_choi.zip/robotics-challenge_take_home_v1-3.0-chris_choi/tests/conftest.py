import pytest
from pathlib import Path

import numpy as np

from trajectory_retiming.retimer import load_joint_trajectory_from_json


@pytest.fixture
def test_traj():
  traj_data_path = Path(__file__).parent / "test_data" / "p2p_trajectory.json"
  return load_joint_trajectory_from_json(str(traj_data_path))
