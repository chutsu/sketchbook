"""
Trajectory Retiming.

This module provides trajectory retiming functionality to ensure all constraints
are satisfied while minimizing the added time penalty.

Usage:
    Visualize a trajectory (joint positions, Cartesian speed, 3D path):

        python3 -m trajectory_retiming.retimer

    With a custom trajectory file:

        python3 -m trajectory_retiming.retimer --trajectory path/to/trajectory.json
"""
import copy
import json
import numpy as np
from scipy.optimize import minimize
from scipy.interpolate import CubicSpline

from .data_types import JointTrajectory, JointState
from .limits import RobotLimits
from .kinematics import forward_kinematics, compute_jacobian, UR30_DH_PARAMS


def load_joint_trajectory_from_json(json_path: str) -> JointTrajectory:
  """Load trajectory from JSON file into JointTrajectory.

    Args:
        json_path: Path to the JSON file containing trajectory data

    Returns:
        JointTrajectory with waypoints and time_from_start
    """
  with open(json_path, 'r') as f:
    data = json.load(f)

  waypoints = [
    JointState(positions=wp['positions']) for wp in data['waypoints']
  ]
  return JointTrajectory(
    waypoints=waypoints,
    time_from_start=data['time_from_start'],
  )


def build_splines(
  waypoints: list[list[float]],
  times: list[float],
) -> list[CubicSpline]:
  """
  Build a cubic spline over time for each joint based the trajectory
  waypoints and times.
  """
  num_joints = len(UR30_DH_PARAMS)
  return [
    CubicSpline(times, waypoints[i], bc_type="clamped")
    for i in range(num_joints)
  ]


def sample_splines(splines: list[CubicSpline], times: list[float]):
  """
  Evaluate joint position, velocity, and acceleration at a set of time samples.

  Calls each spline and its first two analytical derivatives at every point in
  times, then stacks the per-joint results into three (N, 6) arrays.

  Parameters
  ----------
  splines : list of CubicSpline
      One fitted spline per joint, length 6. Each spline maps time -> joint
      angle in radians.
  times : np.ndarray, shape (N,)
      Time points at which to evaluate, in seconds. Must lie within the
      domain used to fit the splines.

  Returns
  -------
  q : np.ndarray, shape (N, 6)
      Joint positions [rad]. Row i is the full configuration at times[i].
  qd : np.ndarray, shape (N, 6)
      Joint velocities [rad/s]. First analytical derivative of the spline.
  qdd : np.ndarray, shape (N, 6)
      Joint accelerations [rad/s²]. Second analytical derivative; piecewise
      linear for a cubic spline.

  Notes
  -----
  Extrapolation (times outside the fitted domain) is not checked and will
  silently produce unreliable values. For a cubic spline, qdd is piecewise
  linear and discontinuous at the knots — sample densely if plotting.
  """
  q = np.column_stack([s(times) for s in splines])
  qd = np.column_stack([s(times, 1) for s in splines])
  qdd = np.column_stack([s(times, 2) for s in splines])
  return q, qd, qdd


def is_feasible(splines, times, limits: RobotLimits = RobotLimits()):
  """
  Check given the splines, times and limits of the robot, does it satisfy the
  robot's:

  - Joint velocity limits
  - Joint acceleration limits
  - End effector velocity limits

  Returns
  -------

  True or False

  """
  # Sample joint positions, velocity and accelerations
  q, qd, qdd = sample_splines(splines, times)

  # Check Joint Velocity: q_dot
  qd_max = np.array(limits.qd_max)[:, np.newaxis]
  for i in range(qd.shape[0]):
    if np.any(np.abs(qd[i, :]) > qd_max):
      return False

  # Check Joint Acceleration: q_ddot
  qdd_max = np.array(limits.qdd_max)[:, np.newaxis]
  for i in range(qdd.shape[0]):
    if np.any(np.abs(qdd[i, :]) > qdd_max):
      return False

  # Check End-effector velocity: J * q_dot
  for i in range(q.shape[0]):
    joint_state = JointState(q[i])

    J = compute_jacobian(joint_state)
    twist = J @ qd[i]
    linear_velocity = np.linalg.norm(twist[:3])
    if linear_velocity > limits.v_cart_max:
      return False

  return True


def optimize_line_search(trajectory: JointTrajectory,
                         limits: RobotLimits = RobotLimits(),
                         s_lo: float = 0.01,
                         s_hi: float = 20.0,
                         ds: float = 0.01) -> JointTrajectory:
  """
  Find a single global scale factor s to scale the trajectory time so that it
  satisfies the limits of the robot. Namely the:

  - Joint velocity limits
  - Joint acceleration limits
  - End effector velocity limits

  This function finds the scale factor by performing a line search from s_lo to
  s_hi with a step size of ds.

  Returns
  -------

  A trajectory with the same waypoints as the input, but with scaled times that
  satisfy the robot limits.

  """
  # Exact times and waypoints per joint
  num_joints = len(UR30_DH_PARAMS)
  times = np.array(trajectory.time_from_start)
  waypoints = [[] for _ in range(num_joints)]
  for joint_state in trajectory.waypoints:
    for i in range(num_joints):
      waypoints[i].append(joint_state.positions[i])

  # Perform line search
  s = s_lo
  while s < s_hi:
    splines = build_splines(waypoints, list(s * times))
    if is_feasible(splines, times, limits):
      break
    s += ds

  return JointTrajectory(trajectory.waypoints, list(s * times))


def kinematic_constraints(splines: list[CubicSpline], times: list[float],
                          limits):
  """
  Returns a dict of constraint margin arrays (positive = satisfied).
  Evaluated at every sample in times.
  """
  N = len(times)
  q, qd, qdd = sample_splines(splines, times)
  v_lin = np.zeros(N)  # end-effector linear speed  [m/s]

  for i in range(N):
    joint_state = JointState(q[i])
    J = compute_jacobian(joint_state)
    twist = J @ qd[i]
    v_lin[i] = np.linalg.norm(twist[:3])

  return {
    "qd_margin": limits.qd_max - np.abs(qd).max(axis=0),
    "qdd_margin": limits.qdd_max - np.abs(qdd).max(axis=0),
    "v_cart_margin": limits.v_cart_max - v_lin,  # (N,)
  }


def optimize_nlls(
    trajectory: JointTrajectory,
    limits=RobotLimits(),
):
  """
  This function scales the trajectory time on a per segment basis. It uses
  SLSQP (Sequential Least Squares Programming) to perform optimization with
  multiple non-linear constraints in mind. Namely the

  - Joint velocity limits
  - Joint acceleration limits
  - End effector velocity limits

  contraints. The object is minimize the total time of the trajectory.

  Returns
  -------

  A trajectory with the same waypoints as the input, but with scaled times that
  satisfy the robot limits.

  """
  n_joints = 6
  n_samples = 300

  times = np.array(trajectory.time_from_start)
  waypoints = [[] for _ in range(n_joints)]
  for joint_state in trajectory.waypoints:
    for i in range(n_joints):
      waypoints[i].append(joint_state.positions[i])

  N = len(times)
  dt0 = np.diff(times).astype(float)

  def times_from_dt(dt: list[float]):
    """ Form time from a list of dts"""
    t = np.zeros(N)
    t[1:] = np.cumsum(dt)
    return t

  def flat_constraints(dt: list[float]):
    """All constraint margins flattened into one vector (must be ≥ 0)."""
    t_abs = times_from_dt(dt)
    t_samp = np.linspace(t_abs[0], t_abs[-1], n_samples)
    spl = build_splines(waypoints, list(t_abs))
    c = kinematic_constraints(spl, t_samp, limits)
    return np.concatenate([
      c["qd_margin"],  # (6,)
      c["qdd_margin"],  # (6,)
      c["v_cart_margin"],  # (N_samples,)
    ])

  def objective(dt_vector):
    """ Objective function"""
    total_time = np.sum(dt_vector)
    return total_time

  res = minimize(
    fun=objective,
    x0=dt0,
    method="SLSQP",
    bounds=[(1e-3, None)] * (N - 1),
    constraints={
      "type": "ineq",
      "fun": flat_constraints
    },
    options={
      "maxiter": 300,
      "ftol": 1e-8
    },
  )
  t_opt = times_from_dt(res.x)
  print(f"Converged: {res.success}  |  Total time: {t_opt[-1]:.3f}s")

  return JointTrajectory(trajectory.waypoints, list(t_opt))


def retime_trajectory(trajectory: JointTrajectory,
                      limits: RobotLimits) -> JointTrajectory:
  """
    Retime trajectory to satisfy all motion constraints.

    The retimed trajectory must satisfy:
    - Cartesian end-effector speed ≤ limits.max_cartesian_speed
    - Joint velocities ≤ limits.max_joint_velocities (for each joint)
    - Joint accelerations ≤ limits.max_joint_accelerations (for each joint)
    - All waypoint positions preserved (path geometry unchanged)
    - Monotonically increasing timestamps
    - Minimized total trajectory duration

    In your implementation, clearly document:
    - Your interpolation model (how position/velocity is computed between waypoints)
    - Your algorithm and approach
    - Any trade-offs or assumptions you make

    Args:
        trajectory: Original joint trajectory with waypoints and timing
        limits: Robot physical limits

    Returns:
        Retimed trajectory with adjusted time_from_start values
    """
  trajectory_copy = copy.deepcopy(trajectory)
  return optimize_line_search(trajectory_copy, limits)
  # return optimize_nlls(trajectory_copy, limits)


def plot_trajectory(trajectory: JointTrajectory) -> None:
  """
    Plot a trajectory object.

    Creates a multi-panel visualization showing:
    - Joint positions over time
    - Joint velocities over time
    - Cartesian speed over time
    - 3D Cartesian end-effector path

    Args:
        trajectory: JointTrajectory object (e.g. from retime_trajectory)
    """
  import matplotlib.pyplot as plt
  from mpl_toolkits.mplot3d import Axes3D

  waypoints = trajectory.waypoints
  time_stamps = np.array(trajectory.time_from_start)

  # Extract joint positions
  num_joints = len(waypoints[0].positions)
  joint_positions = np.array([wp.positions for wp in waypoints])

  # Compute Cartesian positions using FK
  cartesian_positions = []
  for wp in waypoints:
    pose = forward_kinematics(wp)
    cartesian_positions.append(pose.position)
  cartesian_positions = np.array(cartesian_positions)

  # Compute velocities using finite differences: v = delta_pos / delta_t
  delta_t = np.diff(time_stamps)
  delta_t[delta_t == 0] = 1e-9  # Avoid division by zero

  # Joint velocities
  delta_joint_pos = np.diff(joint_positions, axis=0)
  joint_velocities = delta_joint_pos / delta_t[:, np.newaxis]

  # Cartesian velocities and speed using Jacobian
  # v_cartesian = J(q) * q_dot (first 3 rows are linear velocity)
  cartesian_speed = np.zeros(len(waypoints) - 1)
  for i in range(len(waypoints) - 1):
    J = compute_jacobian(waypoints[i])
    # Joint velocities at this segment (q_dot)
    q_dot = joint_velocities[i]
    # Cartesian velocity from Jacobian (first 3 rows are linear velocity)
    v_cartesian = J[:3, :] @ q_dot
    # Speed is the magnitude of linear velocity
    cartesian_speed[i] = np.linalg.norm(v_cartesian)

  # Time stamps for velocities (midpoints between waypoints)
  velocity_time = (time_stamps[:-1] + time_stamps[1:]) / 2

  # Create figure with 2x2 subplots
  fig = plt.figure(figsize=(14, 10))

  # Color palette for joints
  colors = ['#e63946', '#f4a261', '#2a9d8f', '#264653', '#9b5de5', '#00bbf9']
  joint_labels = [f'Joint {i+1}' for i in range(num_joints)]

  # Plot 1: Joint positions over time
  ax1 = fig.add_subplot(2, 2, 1)
  for i in range(num_joints):
    ax1.plot(time_stamps,
             joint_positions[:, i],
             color=colors[i],
             linewidth=2,
             label=joint_labels[i])
  ax1.set_xlabel('Time [s]', fontsize=11)
  ax1.set_ylabel('Position [rad]', fontsize=11)
  ax1.set_title('Joint Positions', fontsize=13, fontweight='bold')
  ax1.legend(loc='upper left', fontsize=9)
  ax1.grid(True, alpha=0.3)
  ax1.set_xlim([time_stamps[0], time_stamps[-1]])

  # Plot 2: Joint velocities over time
  ax2 = fig.add_subplot(2, 2, 2)
  for i in range(num_joints):
    ax2.plot(velocity_time,
             joint_velocities[:, i],
             color=colors[i],
             linewidth=2,
             label=joint_labels[i])
  ax2.set_xlabel('Time [s]', fontsize=11)
  ax2.set_ylabel('Velocity [rad/s]', fontsize=11)
  ax2.set_title('Joint Velocities', fontsize=13, fontweight='bold')
  ax2.legend(loc='upper left', fontsize=9)
  ax2.grid(True, alpha=0.3)
  ax2.set_xlim([time_stamps[0], time_stamps[-1]])

  # Plot 3: Cartesian speed over time
  ax3 = fig.add_subplot(2, 2, 3)
  ax3.plot(velocity_time, cartesian_speed, color='#e63946', linewidth=2.5)
  ax3.fill_between(velocity_time, cartesian_speed, alpha=0.3, color='#e63946')
  ax3.set_xlabel('Time [s]', fontsize=11)
  ax3.set_ylabel('Speed [m/s]', fontsize=11)
  ax3.set_title('Cartesian End-Effector Speed', fontsize=13, fontweight='bold')
  ax3.grid(True, alpha=0.3)
  ax3.set_xlim([time_stamps[0], time_stamps[-1]])
  ax3.set_ylim(bottom=0)

  # Add max speed annotation
  max_speed = np.max(cartesian_speed)
  max_speed_idx = np.argmax(cartesian_speed)
  ax3.axhline(y=max_speed, color='#264653', linestyle='--', alpha=0.7)
  ax3.annotate(f'Max: {max_speed:.3f} m/s',
               xy=(velocity_time[max_speed_idx], max_speed),
               xytext=(10, 5),
               textcoords='offset points',
               fontsize=9,
               color='#264653')

  # Plot 4: 3D Cartesian path
  ax4 = fig.add_subplot(2, 2, 4, projection='3d')
  ax4.plot(cartesian_positions[:, 0],
           cartesian_positions[:, 1],
           cartesian_positions[:, 2],
           color='#e63946',
           linewidth=2.5,
           label='End-effector path')
  ax4.scatter(cartesian_positions[0, 0],
              cartesian_positions[0, 1],
              cartesian_positions[0, 2],
              color='#2a9d8f',
              s=100,
              marker='o',
              label='Start',
              zorder=5)
  ax4.scatter(cartesian_positions[-1, 0],
              cartesian_positions[-1, 1],
              cartesian_positions[-1, 2],
              color='#264653',
              s=100,
              marker='s',
              label='End',
              zorder=5)
  ax4.set_xlabel('X [m]', fontsize=10)
  ax4.set_ylabel('Y [m]', fontsize=10)
  ax4.set_zlabel('Z [m]', fontsize=10)
  ax4.set_title('Cartesian End-Effector Path', fontsize=13, fontweight='bold')
  ax4.legend(loc='upper left', fontsize=9)

  plt.tight_layout()
  plt.show()


def main():
  """Main entry point for trajectory visualization."""
  import argparse
  import os

  parser = argparse.ArgumentParser(
    description='Plot robot trajectory from JSON file')
  parser.add_argument('--trajectory',
                      '-t',
                      type=str,
                      default=os.path.join(os.path.dirname(__file__), '..',
                                           'examples', 'p2p_trajectory.json'),
                      help='Path to trajectory JSON file')
  args = parser.parse_args()

  print(f"Loading trajectory from: {args.trajectory}")
  trajectory = load_joint_trajectory_from_json(args.trajectory)
  trajectory_opt = retime_trajectory(trajectory, RobotLimits())
  plot_trajectory(trajectory_opt)


if __name__ == "__main__":
  main()
