"""Robot physical limits and constraints."""

from typing import List
from dataclasses import dataclass, field


@dataclass
class RobotLimits:
  """Physical limits for robot motion."""
  # Max joint velocities
  # rad/s for each joint (UR30 defaults)
  qd_max: List[float] = field(
    default_factory=lambda: [2.0, 2.0, 2.0, 3.0, 3.0, 3.0])

  # Max joint accelerations
  # rad/s² for each joint (UR30 defaults)
  qdd_max: List[float] = field(
    default_factory=lambda: [5.0, 5.0, 5.0, 8.0, 8.0, 8.0])

  # Max end-effector velcity
  # m/s
  v_cart_max: float = 0.5
